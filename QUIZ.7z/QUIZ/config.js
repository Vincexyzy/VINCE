const CONFIG = {
    titleWeb: "QUIZ NI MARFEL",
    introTitle: 'SPECIAL QUIZ',
    introDesc: `Sana masagutan mo ng tama
    HAHHAHAHAHAHAHAHHAHAHAHAHAH`,
    btnIntro: 'ANSWER',
    title: 'Sino ang Mortal na kaaway ni Gemini?',
    desc: 'may 50 ka pag nasagutan mo:) ',
    btnYes: 'TAURUS',
    btnNo: 'CANCER',
    question: 'Bakit patunayan ang sagotHAHAHA',
    btnReply: 'Send',
    reply: 'Okay master HAHAHHAHAHAHAHAHA',
    mess: 'LT HAHAHHAHAHAHAHAHA',
    messDesc: 'Sana ayus ka lang HAHAHHAHAHAHAHAHA.',
    btnAccept: 'OKAY',
    messLink: 'https://www.facebook.com/groups/599571516776088/?ref=share&mibextid=NSMWBT' //link mess của các bạn. VD: https://www.facebook.com/messages/t/100014188333536
}
